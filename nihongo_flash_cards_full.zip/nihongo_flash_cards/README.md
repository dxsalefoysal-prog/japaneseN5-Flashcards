# Nihongo Flash Cards

A Flutter app for learning JLPT N5 Japanese vocabulary with flashcards, quizzes, and spaced repetition.

## Features
- 105+ N5 vocabulary words
- Flashcard with 3D flip animation
- Quiz mode
- Bookmark system
- Progress tracking
- Dark theme
