// lib/providers/progress_provider.dart
import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/vocabulary.dart';

class ProgressNotifier extends StateNotifier<Map<String, VocabProgress>> {
  ProgressNotifier() : super({}) {
    _load();
  }

  static const String _key = 'vocab_progress';

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return;
    final Map<String, dynamic> data = json.decode(raw);
    state = data.map(
      (k, v) => MapEntry(k, VocabProgress.fromJson(v as Map<String, dynamic>)),
    );
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    final data = state.map((k, v) => MapEntry(k, v.toJson()));
    await prefs.setString(_key, json.encode(data));
  }

  VocabProgress _getOrCreate(String id) {
    return state[id] ?? VocabProgress(vocabId: id);
  }

  void toggleBookmark(String id) {
    final p = _getOrCreate(id);
    p.isBookmarked = !p.isBookmarked;
    state = {...state, id: p};
    _save();
  }

  void toggleLearned(String id) {
    final p = _getOrCreate(id);
    p.isLearned = !p.isLearned;
    state = {...state, id: p};
    _save();
  }

  void markCorrect(String id) {
    final p = _getOrCreate(id);
    p.markCorrect();
    state = {...state, id: p};
    _save();
  }

  void markIncorrect(String id) {
    final p = _getOrCreate(id);
    p.markIncorrect();
    state = {...state, id: p};
    _save();
  }

  bool isBookmarked(String id) => state[id]?.isBookmarked ?? false;
  bool isLearned(String id) => state[id]?.isLearned ?? false;
  int get learnedCount => state.values.where((p) => p.isLearned).length;
  int get bookmarkCount => state.values.where((p) => p.isBookmarked).length;

  List<String> getDueForReview() {
    return state.entries
        .where((e) => e.value.isDueForReview && !e.value.isLearned)
        .map((e) => e.key)
        .toList();
  }

  Map<String, double> getCategoryProgress(
      List<Vocabulary> vocab, List<String> categories) {
    final result = <String, double>{};
    for (final cat in categories) {
      if (cat == 'All') continue;
      final catVocab = vocab.where((v) => v.category == cat).toList();
      if (catVocab.isEmpty) { result[cat] = 0; continue; }
      final learned = catVocab.where((v) => isLearned(v.id)).length;
      result[cat] = learned / catVocab.length;
    }
    return result;
  }
}

final progressProvider =
    StateNotifierProvider<ProgressNotifier, Map<String, VocabProgress>>(
  (ref) => ProgressNotifier(),
);
