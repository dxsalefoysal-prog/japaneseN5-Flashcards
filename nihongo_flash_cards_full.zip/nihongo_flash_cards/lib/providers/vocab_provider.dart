// lib/providers/vocab_provider.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/vocabulary.dart';
import '../services/local_data_service.dart';

// All vocabulary
final allVocabProvider = FutureProvider<List<Vocabulary>>((ref) async {
  return LocalDataService.loadVocabulary();
});

// Selected category
final selectedCategoryProvider = StateProvider<String>((ref) => 'All');

// Search query
final searchQueryProvider = StateProvider<String>((ref) => '');

// Current card index
final currentIndexProvider = StateProvider<int>((ref) => 0);

// Filtered vocabulary based on category + search
final filteredVocabProvider = Provider<AsyncValue<List<Vocabulary>>>((ref) {
  final allAsync = ref.watch(allVocabProvider);
  final category = ref.watch(selectedCategoryProvider);
  final query = ref.watch(searchQueryProvider);

  return allAsync.when(
    data: (all) {
      var result = all;
      if (category != 'All') {
        result = result.where((v) => v.category == category).toList();
      }
      if (query.isNotEmpty) {
        final q = query.toLowerCase();
        result = result.where((v) =>
          v.kanji.contains(query) ||
          v.hiragana.contains(query) ||
          v.romaji.toLowerCase().contains(q) ||
          v.englishMeaning.toLowerCase().contains(q) ||
          v.banglaMeaning.contains(query)
        ).toList();
      }
      return AsyncValue.data(result);
    },
    loading: () => const AsyncValue.loading(),
    error: (e, s) => AsyncValue.error(e, s),
  );
});

// Shuffled deck for flashcards
final shuffledDeckProvider = StateProvider<List<Vocabulary>>((ref) => []);

final isDeckShuffledProvider = StateProvider<bool>((ref) => false);
