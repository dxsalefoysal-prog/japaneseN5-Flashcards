// lib/models/vocabulary.dart

class Vocabulary {
  final String id;
  final String kanji;
  final String hiragana;
  final String romaji;
  final String englishMeaning;
  final String banglaMeaning;
  final String partOfSpeech;
  final String category;
  final String exampleSentence;
  final String exampleTranslation;
  final String? grammarNote;
  final int jlptLevel;

  const Vocabulary({
    required this.id,
    required this.kanji,
    required this.hiragana,
    required this.romaji,
    required this.englishMeaning,
    required this.banglaMeaning,
    required this.partOfSpeech,
    required this.category,
    required this.exampleSentence,
    required this.exampleTranslation,
    this.grammarNote,
    this.jlptLevel = 5,
  });

  factory Vocabulary.fromJson(Map<String, dynamic> json) {
    return Vocabulary(
      id: json['id'] as String,
      kanji: json['kanji'] as String,
      hiragana: json['hiragana'] as String,
      romaji: json['romaji'] as String,
      englishMeaning: json['english_meaning'] as String,
      banglaMeaning: json['bangla_meaning'] as String,
      partOfSpeech: json['part_of_speech'] as String,
      category: json['category'] as String,
      exampleSentence: json['example_sentence'] as String,
      exampleTranslation: json['example_translation'] as String,
      grammarNote: json['grammar_note'] as String?,
      jlptLevel: json['jlpt_level'] as int? ?? 5,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'kanji': kanji,
      'hiragana': hiragana,
      'romaji': romaji,
      'english_meaning': englishMeaning,
      'bangla_meaning': banglaMeaning,
      'part_of_speech': partOfSpeech,
      'category': category,
      'example_sentence': exampleSentence,
      'example_translation': exampleTranslation,
      'grammar_note': grammarNote,
      'jlpt_level': jlptLevel,
    };
  }
}

class VocabProgress {
  final String vocabId;
  bool isLearned;
  bool isBookmarked;
  int reviewCount;
  int correctCount;
  DateTime? lastReviewed;
  DateTime? nextReviewDate;
  int srsLevel; // 0-5, higher = longer interval

  VocabProgress({
    required this.vocabId,
    this.isLearned = false,
    this.isBookmarked = false,
    this.reviewCount = 0,
    this.correctCount = 0,
    this.lastReviewed,
    this.nextReviewDate,
    this.srsLevel = 0,
  });

  factory VocabProgress.fromJson(Map<String, dynamic> json) {
    return VocabProgress(
      vocabId: json['vocab_id'] as String,
      isLearned: json['is_learned'] as bool? ?? false,
      isBookmarked: json['is_bookmarked'] as bool? ?? false,
      reviewCount: json['review_count'] as int? ?? 0,
      correctCount: json['correct_count'] as int? ?? 0,
      lastReviewed: json['last_reviewed'] != null
          ? DateTime.parse(json['last_reviewed'] as String)
          : null,
      nextReviewDate: json['next_review_date'] != null
          ? DateTime.parse(json['next_review_date'] as String)
          : null,
      srsLevel: json['srs_level'] as int? ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'vocab_id': vocabId,
      'is_learned': isLearned,
      'is_bookmarked': isBookmarked,
      'review_count': reviewCount,
      'correct_count': correctCount,
      'last_reviewed': lastReviewed?.toIso8601String(),
      'next_review_date': nextReviewDate?.toIso8601String(),
      'srs_level': srsLevel,
    };
  }

  // SRS interval in days based on level
  static const List<int> srsIntervals = [1, 3, 7, 14, 30, 60];

  void markCorrect() {
    reviewCount++;
    correctCount++;
    lastReviewed = DateTime.now();
    if (srsLevel < 5) srsLevel++;
    nextReviewDate =
        DateTime.now().add(Duration(days: srsIntervals[srsLevel]));
    if (srsLevel >= 4) isLearned = true;
  }

  void markIncorrect() {
    reviewCount++;
    lastReviewed = DateTime.now();
    if (srsLevel > 0) srsLevel--;
    nextReviewDate =
        DateTime.now().add(Duration(days: srsIntervals[srsLevel]));
    isLearned = false;
  }

  bool get isDueForReview {
    if (nextReviewDate == null) return true;
    return DateTime.now().isAfter(nextReviewDate!);
  }

  double get accuracy =>
      reviewCount == 0 ? 0 : (correctCount / reviewCount) * 100;
}
