// lib/widgets/flashcard_widget.dart
import 'dart:math';
import 'package:flutter/material.dart';
import '../models/vocabulary.dart';

class FlashcardWidget extends StatefulWidget {
  final Vocabulary vocab;
  final bool isBookmarked;
  final bool isLearned;
  final VoidCallback onBookmark;
  final VoidCallback onLearned;
  final VoidCallback onAudio;
  final VoidCallback onNext;
  final VoidCallback onPrev;

  const FlashcardWidget({
    super.key,
    required this.vocab,
    required this.isBookmarked,
    required this.isLearned,
    required this.onBookmark,
    required this.onLearned,
    required this.onAudio,
    required this.onNext,
    required this.onPrev,
  });

  @override
  State<FlashcardWidget> createState() => _FlashcardWidgetState();
}

class _FlashcardWidgetState extends State<FlashcardWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  bool _isFlipped = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _animation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOutCubic),
    );
  }

  @override
  void didUpdateWidget(FlashcardWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.vocab.id != widget.vocab.id) {
      _isFlipped = false;
      _controller.reverse();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _toggleFlip() {
    setState(() {
      _isFlipped = !_isFlipped;
      if (_isFlipped) {
        _controller.forward();
      } else {
        _controller.reverse();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _toggleFlip,
      onHorizontalDragEnd: (details) {
        if (details.primaryVelocity == null) return;
        if (details.primaryVelocity! < -300) {
          widget.onNext();
        } else if (details.primaryVelocity! > 300) {
          widget.onPrev();
        }
      },
      child: AnimatedBuilder(
        animation: _animation,
        builder: (context, child) {
          final angle = _animation.value * pi;
          final isBack = angle > pi / 2;
          return Transform(
            transform: Matrix4.identity()
              ..setEntry(3, 2, 0.001)
              ..rotateY(angle),
            alignment: Alignment.center,
            child: isBack
                ? Transform(
                    transform: Matrix4.identity()..rotateY(pi),
                    alignment: Alignment.center,
                    child: _buildBackFace(),
                  )
                : _buildFrontFace(),
          );
        },
      ),
    );
  }

  Widget _buildFrontFace() {
    final v = widget.vocab;
    return Container(
      width: double.infinity,
      height: 300,
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1E),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF2E2E32), width: 0.5),
      ),
      child: Stack(
        children: [
          // Part of speech badge
          Positioned(
            top: 16, left: 16,
            child: _buildBadge(v.partOfSpeech, const Color(0xFF252528), const Color(0xFF9B9A94)),
          ),
          // Category badge
          Positioned(
            top: 16, right: 16,
            child: _buildBadge(v.category, const Color(0xFF252528), const Color(0xFF9B9A94)),
          ),
          // Main content
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  v.kanji,
                  style: const TextStyle(
                    fontFamily: 'NotoSansJP',
                    fontSize: 72,
                    fontWeight: FontWeight.w300,
                    color: Color(0xFFF0EFE9),
                    height: 1.0,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  v.romaji,
                  style: const TextStyle(
                    fontSize: 16,
                    color: Color(0xFF6B6B70),
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.touch_app_outlined, size: 14, color: Color(0xFF5A5A5E)),
                    const SizedBox(width: 4),
                    const Text(
                      'tap to reveal',
                      style: TextStyle(fontSize: 12, color: Color(0xFF5A5A5E)),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // Audio button
          Positioned(
            bottom: 14, right: 14,
            child: _buildIconBtn(Icons.volume_up_outlined, widget.onAudio),
          ),
        ],
      ),
    );
  }

  Widget _buildBackFace() {
    final v = widget.vocab;
    return Container(
      width: double.infinity,
      height: 300,
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1E),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF2E2E32), width: 0.5),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  v.kanji,
                  style: const TextStyle(
                    fontFamily: 'NotoSansJP',
                    fontSize: 32,
                    fontWeight: FontWeight.w400,
                    color: Color(0xFFF0EFE9),
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  v.hiragana,
                  style: const TextStyle(
                    fontFamily: 'NotoSansJP',
                    fontSize: 20,
                    color: Color(0xFF9B9A94),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                _buildMeaningChip(v.englishMeaning, const Color(0xFF0C447C), const Color(0xFFB5D4F4)),
                _buildMeaningChip(v.banglaMeaning, const Color(0xFF085041), const Color(0xFF9FE1CB)),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF252528),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFF2E2E32), width: 0.5),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    v.exampleSentence,
                    style: const TextStyle(
                      fontFamily: 'NotoSansJP',
                      fontSize: 15,
                      color: Color(0xFFF0EFE9),
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    v.exampleTranslation,
                    style: const TextStyle(
                      fontSize: 12,
                      color: Color(0xFF9B9A94),
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
            if (v.grammarNote != null && v.grammarNote!.isNotEmpty) ...[
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFF412402),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.info_outline, size: 14, color: Color(0xFFEF9F27)),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        v.grammarNote!,
                        style: const TextStyle(
                          fontSize: 12,
                          color: Color(0xFFEF9F27),
                          height: 1.4,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildBadge(String label, Color bg, Color fg) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFF2E2E32), width: 0.5),
      ),
      child: Text(label, style: TextStyle(fontSize: 11, color: fg)),
    );
  }

  Widget _buildMeaningChip(String text, Color bg, Color fg) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(text, style: TextStyle(fontSize: 13, color: fg)),
    );
  }

  Widget _buildIconBtn(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          color: const Color(0xFF252528),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: const Color(0xFF2E2E32), width: 0.5),
        ),
        child: Icon(icon, size: 16, color: const Color(0xFF9B9A94)),
      ),
    );
  }
}
