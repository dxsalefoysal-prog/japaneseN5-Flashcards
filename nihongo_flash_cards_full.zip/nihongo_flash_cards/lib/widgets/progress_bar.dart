// lib/widgets/progress_bar.dart
import 'package:flutter/material.dart';

class ProgressBar extends StatelessWidget {
  final int current;
  final int total;

  const ProgressBar({super.key, required this.current, required this.total});

  @override
  Widget build(BuildContext context) {
    final progress = total > 0 ? current / total : 0.0;
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: '$current',
                    style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w500,
                      color: Color(0xFFF0EFE9),
                    ),
                  ),
                  TextSpan(
                    text: ' / $total',
                    style: const TextStyle(fontSize: 14, color: Color(0xFF9B9A94)),
                  ),
                ],
              ),
            ),
            Text(
              '${(progress * 100).round()}%',
              style: const TextStyle(fontSize: 12, color: Color(0xFF9B9A94)),
            ),
          ],
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(2),
          child: LinearProgressIndicator(
            value: progress,
            backgroundColor: const Color(0xFF252528),
            valueColor: const AlwaysStoppedAnimation(Color(0xFFE8614A)),
            minHeight: 3,
          ),
        ),
      ],
    );
  }
}
