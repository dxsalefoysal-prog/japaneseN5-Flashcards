// lib/services/local_data_service.dart
import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/vocabulary.dart';

class LocalDataService {
  static const String _assetPath = 'assets/data/n5_vocab.json';
  static List<Vocabulary>? _cache;

  static Future<List<Vocabulary>> loadVocabulary() async {
    if (_cache != null) return _cache!;
    final String jsonString = await rootBundle.loadString(_assetPath);
    final Map<String, dynamic> data = json.decode(jsonString);
    final List<dynamic> vocabList = data['vocabulary'] as List<dynamic>;
    _cache = vocabList
        .map((item) => Vocabulary.fromJson(item as Map<String, dynamic>))
        .toList();
    return _cache!;
  }

  static Future<List<Vocabulary>> loadByCategory(String category) async {
    final all = await loadVocabulary();
    if (category == 'All') return all;
    return all.where((v) => v.category == category).toList();
  }

  static Future<List<Vocabulary>> search(String query) async {
    if (query.trim().isEmpty) return loadVocabulary();
    final all = await loadVocabulary();
    final q = query.toLowerCase();
    return all.where((v) =>
      v.kanji.contains(query) ||
      v.hiragana.contains(query) ||
      v.romaji.toLowerCase().contains(q) ||
      v.englishMeaning.toLowerCase().contains(q) ||
      v.banglaMeaning.contains(query)
    ).toList();
  }

  static List<String> get categories => [
    'All', 'Verbs', 'Adjectives', 'Nouns',
    'Daily Conversation', 'Numbers', 'Time',
  ];
}
