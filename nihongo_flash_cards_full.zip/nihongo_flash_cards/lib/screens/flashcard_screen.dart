// lib/screens/flashcard_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/vocab_provider.dart';
import '../providers/progress_provider.dart';
import '../services/local_data_service.dart';
import '../services/audio_service.dart';
import '../widgets/flashcard_widget.dart';
import '../widgets/progress_bar.dart';

class FlashcardScreen extends ConsumerStatefulWidget {
  const FlashcardScreen({super.key});

  @override
  ConsumerState<FlashcardScreen> createState() => _FlashcardScreenState();
}

class _FlashcardScreenState extends ConsumerState<FlashcardScreen> {
  final _audio = AudioService();
  late PageController _pageController;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
  }

  @override
  void dispose() {
    _pageController.dispose();
    _audio.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filteredAsync = ref.watch(filteredVocabProvider);
    final currentIdx = ref.watch(currentIndexProvider);
    final progressNotifier = ref.read(progressProvider.notifier);
    final category = ref.watch(selectedCategoryProvider);

    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0F),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0D0D0F),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(category == 'All' ? 'Flashcards' : category),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert, size: 20),
            color: const Color(0xFF1A1A1E),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'shuffle', child: Text('Shuffle deck')),
              const PopupMenuItem(value: 'reset', child: Text('Reset progress')),
            ],
            onSelected: (val) {
              if (val == 'shuffle') {
                final filtered = ref.read(filteredVocabProvider);
                filtered.whenData((list) {
                  final shuffled = [...list]..shuffle();
                  ref.read(shuffledDeckProvider.notifier).state = shuffled;
                  ref.read(isDeckShuffledProvider.notifier).state = true;
                  ref.read(currentIndexProvider.notifier).state = 0;
                });
              }
            },
          ),
        ],
      ),
      body: filteredAsync.when(
        data: (vocab) {
          if (vocab.isEmpty) {
            return const Center(
              child: Text('No vocabulary found.', style: TextStyle(color: Color(0xFF9B9A94))),
            );
          }
          final isShuffled = ref.watch(isDeckShuffledProvider);
          final displayList = isShuffled ? ref.watch(shuffledDeckProvider) : vocab;
          final idx = currentIdx.clamp(0, displayList.length - 1);
          final current = displayList[idx];
          final progressData = ref.watch(progressProvider);

          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                const SizedBox(height: 8),
                ProgressBar(current: idx + 1, total: displayList.length),
                const SizedBox(height: 20),
                // Category filter chips
                SizedBox(
                  height: 34,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: LocalDataService.categories.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 6),
                    itemBuilder: (_, i) {
                      final cat = LocalDataService.categories[i];
                      final isSelected = cat == category;
                      return FilterChip(
                        label: Text(cat),
                        selected: isSelected,
                        onSelected: (_) {
                          ref.read(selectedCategoryProvider.notifier).state = cat;
                          ref.read(currentIndexProvider.notifier).state = 0;
                          ref.read(isDeckShuffledProvider.notifier).state = false;
                        },
                        showCheckmark: false,
                      );
                    },
                  ),
                ),
                const SizedBox(height: 16),
                // Search bar
                TextField(
                  decoration: const InputDecoration(
                    hintText: 'Search vocabulary...',
                    prefixIcon: Icon(Icons.search, size: 18, color: Color(0xFF6B6B70)),
                    contentPadding: EdgeInsets.symmetric(vertical: 10),
                  ),
                  style: const TextStyle(fontSize: 14, color: Color(0xFFF0EFE9)),
                  onChanged: (v) {
                    ref.read(searchQueryProvider.notifier).state = v;
                    ref.read(currentIndexProvider.notifier).state = 0;
                  },
                ),
                const SizedBox(height: 20),
                // Card stack visual effect
                Expanded(
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // Stack shadows
                      Positioned(
                        bottom: 60,
                        child: Transform.translate(
                          offset: const Offset(0, 8),
                          child: Container(
                            width: MediaQuery.of(context).size.width - 64,
                            height: 300,
                            decoration: BoxDecoration(
                              color: const Color(0xFF1A1A1E),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: const Color(0xFF2E2E32), width: 0.5),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 60,
                        child: Transform.translate(
                          offset: const Offset(0, 4),
                          child: Container(
                            width: MediaQuery.of(context).size.width - 48,
                            height: 300,
                            decoration: BoxDecoration(
                              color: const Color(0xFF1E1E22),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: const Color(0xFF2E2E32), width: 0.5),
                            ),
                          ),
                        ),
                      ),
                      // Main card
                      Column(
                        children: [
                          FlashcardWidget(
                            vocab: current,
                            isBookmarked: progressNotifier.isBookmarked(current.id),
                            isLearned: progressNotifier.isLearned(current.id),
                            onBookmark: () => ref.read(progressProvider.notifier).toggleBookmark(current.id),
                            onLearned: () => ref.read(progressProvider.notifier).toggleLearned(current.id),
                            onAudio: () => _audio.speak(current.kanji),
                            onNext: () {
                              final next = (idx + 1) % displayList.length;
                              ref.read(currentIndexProvider.notifier).state = next;
                            },
                            onPrev: () {
                              final prev = idx > 0 ? idx - 1 : displayList.length - 1;
                              ref.read(currentIndexProvider.notifier).state = prev;
                            },
                          ),
                          const SizedBox(height: 20),
                          // Controls
                          Row(
                            children: [
                              _NavButton(
                                icon: Icons.arrow_back,
                                label: 'Prev',
                                onTap: () {
                                  final prev = idx > 0 ? idx - 1 : displayList.length - 1;
                                  ref.read(currentIndexProvider.notifier).state = prev;
                                },
                              ),
                              const SizedBox(width: 10),
                              // Bookmark
                              _ActionButton(
                                icon: progressNotifier.isBookmarked(current.id)
                                    ? Icons.bookmark
                                    : Icons.bookmark_border,
                                color: progressNotifier.isBookmarked(current.id)
                                    ? const Color(0xFFE8614A)
                                    : const Color(0xFF9B9A94),
                                onTap: () => ref.read(progressProvider.notifier).toggleBookmark(current.id),
                              ),
                              const SizedBox(width: 10),
                              // Learned
                              _ActionButton(
                                icon: Icons.check,
                                color: progressNotifier.isLearned(current.id)
                                    ? const Color(0xFF1DB97A)
                                    : const Color(0xFF9B9A94),
                                filled: progressNotifier.isLearned(current.id),
                                onTap: () => ref.read(progressProvider.notifier).toggleLearned(current.id),
                              ),
                              const SizedBox(width: 10),
                              _NavButton(
                                icon: Icons.arrow_forward,
                                label: 'Next',
                                trailing: true,
                                onTap: () {
                                  final next = (idx + 1) % displayList.length;
                                  ref.read(currentIndexProvider.notifier).state = next;
                                },
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
        loading: () => const Center(child: CircularProgressIndicator(color: Color(0xFFE8614A))),
        error: (e, _) => Center(child: Text('Error: $e')),
      ),
    );
  }
}

class _NavButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool trailing;
  final VoidCallback onTap;

  const _NavButton({
    required this.icon,
    required this.label,
    this.trailing = false,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A1E),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF2E2E32), width: 0.5),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: trailing
                ? [Text(label, style: const TextStyle(fontSize: 13, color: Color(0xFF9B9A94))),
                   const SizedBox(width: 4),
                   Icon(icon, size: 16, color: const Color(0xFF9B9A94))]
                : [Icon(icon, size: 16, color: const Color(0xFF9B9A94)),
                   const SizedBox(width: 4),
                   Text(label, style: const TextStyle(fontSize: 13, color: Color(0xFF9B9A94)))],
          ),
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final bool filled;
  final VoidCallback onTap;

  const _ActionButton({
    required this.icon,
    required this.color,
    this.filled = false,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: filled ? color.withOpacity(0.12) : const Color(0xFF1A1A1E),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: filled ? color : const Color(0xFF2E2E32),
            width: 0.5,
          ),
        ),
        child: Icon(icon, size: 18, color: color),
      ),
    );
  }
}
