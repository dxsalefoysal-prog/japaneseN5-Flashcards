// lib/screens/home_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/vocab_provider.dart';
import '../providers/progress_provider.dart';
import '../services/local_data_service.dart';
import 'flashcard_screen.dart';
import 'quiz_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final allAsync = ref.watch(allVocabProvider);
    final progress = ref.watch(progressProvider);
    final learned = ref.read(progressProvider.notifier).learnedCount;
    final bookmarks = ref.read(progressProvider.notifier).bookmarkCount;

    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0F),
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: const Color(0xFFE8614A),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          alignment: Alignment.center,
                          child: const Text('日', style: TextStyle(
                            color: Colors.white, fontSize: 20, fontWeight: FontWeight.w500,
                          )),
                        ),
                        const SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Nihongo Flash Cards',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: Color(0xFFF0EFE9)),
                            ),
                            Text('JLPT N5 Vocabulary',
                              style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 28),
                    // Stats row
                    allAsync.when(
                      data: (all) => Row(
                        children: [
                          _StatCard(label: 'Total', value: '${all.length}', icon: Icons.library_books_outlined),
                          const SizedBox(width: 10),
                          _StatCard(label: 'Learned', value: '$learned', icon: Icons.check_circle_outline, color: const Color(0xFF1DB97A)),
                          const SizedBox(width: 10),
                          _StatCard(label: 'Saved', value: '$bookmarks', icon: Icons.bookmark_outline, color: const Color(0xFFE8614A)),
                        ],
                      ),
                      loading: () => const SizedBox(height: 80),
                      error: (_, __) => const SizedBox(),
                    ),
                    const SizedBox(height: 28),
                    // Mode cards
                    const Text('Study modes',
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Color(0xFFF0EFE9)),
                    ),
                    const SizedBox(height: 12),
                    _ModeCard(
                      icon: Icons.style_outlined,
                      title: 'Flashcards',
                      subtitle: 'Review vocabulary with flipping cards',
                      color: const Color(0xFFE8614A),
                      onTap: () => Navigator.push(context, MaterialPageRoute(
                        builder: (_) => const FlashcardScreen(),
                      )),
                    ),
                    const SizedBox(height: 10),
                    _ModeCard(
                      icon: Icons.quiz_outlined,
                      title: 'Quiz Mode',
                      subtitle: 'Test your knowledge with multiple choice',
                      color: const Color(0xFF378ADD),
                      onTap: () => Navigator.push(context, MaterialPageRoute(
                        builder: (_) => const QuizScreen(),
                      )),
                    ),
                    const SizedBox(height: 28),
                    // Category quick access
                    const Text('Browse by category',
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Color(0xFFF0EFE9)),
                    ),
                    const SizedBox(height: 12),
                  ],
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (context, i) {
                    final cats = LocalDataService.categories.where((c) => c != 'All').toList();
                    if (i >= cats.length) return null;
                    final cat = cats[i];
                    final icons = {
                      'Verbs': Icons.run_circle_outlined,
                      'Adjectives': Icons.star_outline,
                      'Nouns': Icons.category_outlined,
                      'Daily Conversation': Icons.chat_bubble_outline,
                      'Numbers': Icons.tag,
                      'Time': Icons.access_time_outlined,
                    };
                    return _CategoryTile(
                      label: cat,
                      icon: icons[cat] ?? Icons.book_outlined,
                      onTap: () {
                        ref.read(selectedCategoryProvider.notifier).state = cat;
                        Navigator.push(context, MaterialPageRoute(
                          builder: (_) => const FlashcardScreen(),
                        ));
                      },
                    );
                  },
                  childCount: LocalDataService.categories.length - 1,
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 2.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    this.color = const Color(0xFF9B9A94),
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1A1E),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFF2E2E32), width: 0.5),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 18, color: color),
            const SizedBox(height: 8),
            Text(value, style: const TextStyle(
              fontSize: 22, fontWeight: FontWeight.w500, color: Color(0xFFF0EFE9),
            )),
            Text(label, style: const TextStyle(fontSize: 11, color: Color(0xFF6B6B70))),
          ],
        ),
      ),
    );
  }
}

class _ModeCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _ModeCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1A1E),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFF2E2E32), width: 0.5),
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(
                    fontSize: 15, fontWeight: FontWeight.w500, color: Color(0xFFF0EFE9),
                  )),
                  const SizedBox(height: 2),
                  Text(subtitle, style: const TextStyle(fontSize: 12, color: Color(0xFF6B6B70))),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, size: 14, color: Colors.grey[700]),
          ],
        ),
      ),
    );
  }
}

class _CategoryTile extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  const _CategoryTile({required this.label, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1A1E),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFF2E2E32), width: 0.5),
        ),
        child: Row(
          children: [
            Icon(icon, size: 18, color: const Color(0xFF9B9A94)),
            const SizedBox(width: 8),
            Expanded(
              child: Text(label, style: const TextStyle(
                fontSize: 13, color: Color(0xFFD0CFC9),
              ), overflow: TextOverflow.ellipsis),
            ),
          ],
        ),
      ),
    );
  }
}
