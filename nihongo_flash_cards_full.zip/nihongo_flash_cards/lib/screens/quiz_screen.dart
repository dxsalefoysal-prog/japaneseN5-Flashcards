// lib/screens/quiz_screen.dart
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/vocabulary.dart';
import '../providers/vocab_provider.dart';
import '../providers/progress_provider.dart';

class QuizScreen extends ConsumerStatefulWidget {
  const QuizScreen({super.key});

  @override
  ConsumerState<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends ConsumerState<QuizScreen> {
  List<Vocabulary> _deck = [];
  int _current = 0;
  int _score = 0;
  int _correct = 0;
  int _streak = 0;
  String? _selectedId;
  bool _answered = false;
  List<Vocabulary> _options = [];
  final _rng = Random();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadDeck());
  }

  void _loadDeck() {
    final allAsync = ref.read(allVocabProvider);
    allAsync.whenData((all) {
      setState(() {
        _deck = [...all]..shuffle(_rng);
        _score = 0; _correct = 0; _streak = 0; _current = 0; _answered = false;
        _buildOptions();
      });
    });
  }

  void _buildOptions() {
    if (_deck.isEmpty) return;
    final correct = _deck[_current];
    final allAsync = ref.read(allVocabProvider);
    allAsync.whenData((all) {
      final pool = all.where((v) => v.id != correct.id).toList()..shuffle(_rng);
      final wrong = pool.take(3).toList();
      _options = [...wrong, correct]..shuffle(_rng);
      setState(() {});
    });
  }

  void _select(String id) {
    if (_answered) return;
    final correct = _deck[_current];
    setState(() {
      _selectedId = id;
      _answered = true;
      if (id == correct.id) {
        _correct++;
        _streak++;
        _score += 10 + (_streak > 1 ? (_streak - 1) * 2 : 0);
        ref.read(progressProvider.notifier).markCorrect(correct.id);
      } else {
        _streak = 0;
        ref.read(progressProvider.notifier).markIncorrect(correct.id);
      }
    });
  }

  void _next() {
    setState(() {
      _current = (_current + 1) % _deck.length;
      _selectedId = null;
      _answered = false;
      _buildOptions();
    });
  }

  Color _optionColor(String id) {
    if (!_answered) return const Color(0xFF1A1A1E);
    final correct = _deck[_current];
    if (id == correct.id) return const Color(0xFF173404);
    if (id == _selectedId) return const Color(0xFF501313);
    return const Color(0xFF1A1A1E);
  }

  Color _optionBorder(String id) {
    if (!_answered) return const Color(0xFF2E2E32);
    final correct = _deck[_current];
    if (id == correct.id) return const Color(0xFF639922);
    if (id == _selectedId) return const Color(0xFFA32D2D);
    return const Color(0xFF2E2E32);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0F),
      appBar: AppBar(
        title: const Text('Quiz Mode'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          TextButton(
            onPressed: _loadDeck,
            child: const Text('Restart', style: TextStyle(color: Color(0xFFE8614A), fontSize: 13)),
          ),
        ],
      ),
      body: _deck.isEmpty
          ? const Center(child: CircularProgressIndicator(color: Color(0xFFE8614A)))
          : Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  // Score row
                  Row(
                    children: [
                      _ScoreCard(label: 'Score', value: '$_score', color: const Color(0xFFE8614A)),
                      const SizedBox(width: 10),
                      _ScoreCard(label: 'Correct', value: '$_correct', color: const Color(0xFF1DB97A)),
                      const SizedBox(width: 10),
                      _ScoreCard(label: 'Streak 🔥', value: '$_streak', color: const Color(0xFFEF9F27)),
                    ],
                  ),
                  const SizedBox(height: 20),
                  // Question card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 24),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A1E),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFF2E2E32), width: 0.5),
                    ),
                    child: Column(
                      children: [
                        Text(
                          _deck[_current].kanji,
                          style: const TextStyle(
                            fontFamily: 'NotoSansJP',
                            fontSize: 56,
                            fontWeight: FontWeight.w300,
                            color: Color(0xFFF0EFE9),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '${_deck[_current].hiragana}  ·  ${_deck[_current].romaji}',
                          style: const TextStyle(fontSize: 14, color: Color(0xFF6B6B70)),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'What does this mean?',
                          style: const TextStyle(fontSize: 13, color: Color(0xFF9B9A94)),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Options
                  ...(_options.map((opt) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: GestureDetector(
                      onTap: () => _select(opt.id),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                        decoration: BoxDecoration(
                          color: _optionColor(opt.id),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: _optionBorder(opt.id), width: 0.5),
                        ),
                        child: Column(
                          children: [
                            Text(
                              opt.englishMeaning,
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 14, color: Color(0xFFF0EFE9)),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              opt.banglaMeaning,
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 11, color: Color(0xFF9B9A94)),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ))),
                  const Spacer(),
                  if (_answered)
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _next,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFE8614A),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          elevation: 0,
                        ),
                        child: const Text('Next question →', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                      ),
                    ),
                  const SizedBox(height: 8),
                ],
              ),
            ),
    );
  }
}

class _ScoreCard extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _ScoreCard({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1A1E),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFF2E2E32), width: 0.5),
        ),
        child: Column(
          children: [
            Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w500, color: color)),
            const SizedBox(height: 2),
            Text(label, style: const TextStyle(fontSize: 11, color: Color(0xFF6B6B70))),
          ],
        ),
      ),
    );
  }
}
