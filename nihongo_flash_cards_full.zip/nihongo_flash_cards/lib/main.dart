// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const ProviderScope(child: NihongoApp()));
}

class NihongoApp extends StatelessWidget {
  const NihongoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Nihongo Flash Cards',
      debugShowCheckedModeBanner: false,
      theme: _buildTheme(),
      home: const HomeScreen(),
    );
  }

  ThemeData _buildTheme() {
    final base = ThemeData.dark();
    return base.copyWith(
      scaffoldBackgroundColor: const Color(0xFF0D0D0F),
      colorScheme: const ColorScheme.dark(
        primary: Color(0xFFE8614A),
        secondary: Color(0xFF1DB97A),
        surface: Color(0xFF1A1A1E),
        background: Color(0xFF0D0D0F),
        onPrimary: Colors.white,
        onSecondary: Colors.white,
        onSurface: Color(0xFFF0EFE9),
        onBackground: Color(0xFFF0EFE9),
      ),
      textTheme: GoogleFonts.notoSansTextTheme(base.textTheme).copyWith(
        displayLarge: GoogleFonts.notoSansJp(
          fontSize: 64, fontWeight: FontWeight.w300, color: const Color(0xFFF0EFE9),
        ),
        headlineMedium: GoogleFonts.notoSansJp(
          fontSize: 28, fontWeight: FontWeight.w400, color: const Color(0xFFF0EFE9),
        ),
        titleLarge: GoogleFonts.notoSans(
          fontSize: 18, fontWeight: FontWeight.w500, color: const Color(0xFFF0EFE9),
        ),
        bodyMedium: GoogleFonts.notoSans(
          fontSize: 14, color: const Color(0xFF9B9A94),
        ),
      ),
      cardTheme: CardTheme(
        color: const Color(0xFF1A1A1E),
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: Color(0xFF2E2E32), width: 0.5),
        ),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: const Color(0xFF0D0D0F),
        elevation: 0,
        centerTitle: false,
        titleTextStyle: GoogleFonts.notoSans(
          fontSize: 18, fontWeight: FontWeight.w500, color: const Color(0xFFF0EFE9),
        ),
        iconTheme: const IconThemeData(color: Color(0xFFF0EFE9)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF1A1A1E),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF2E2E32), width: 0.5),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF2E2E32), width: 0.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFE8614A), width: 1),
        ),
        hintStyle: const TextStyle(color: Color(0xFF5A5A5E), fontSize: 14),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: const Color(0xFF252528),
        selectedColor: const Color(0xFFE8614A),
        labelStyle: const TextStyle(fontSize: 12, color: Color(0xFF9B9A94)),
        secondaryLabelStyle: const TextStyle(fontSize: 12, color: Colors.white),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: Color(0xFF2E2E32), width: 0.5),
        ),
      ),
    );
  }
}
