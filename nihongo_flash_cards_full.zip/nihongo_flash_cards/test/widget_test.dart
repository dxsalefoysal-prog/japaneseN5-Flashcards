import 'package:flutter_test/flutter_test.dart';
import 'package:nihongo_flash_cards/main.dart';

void main() {
  testWidgets('App smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(const NihongoApp());
  });
}
