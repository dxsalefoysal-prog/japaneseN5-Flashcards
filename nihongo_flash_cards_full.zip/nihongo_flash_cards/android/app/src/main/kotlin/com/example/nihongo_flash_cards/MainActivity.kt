package com.example.nihongo_flash_cards

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
